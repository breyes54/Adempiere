1. Install launch4j 3.x from http://launch4j.sourceforge.net/
2. Open Adempiere.xml from launch4j and start the build process
3. A new Adempiere.exe file will be written into the Release folder.

